/**
 * 
 */
/**
 * @author Lukáš
 *
 */
module projectv2 {
	requires java.sql;
}